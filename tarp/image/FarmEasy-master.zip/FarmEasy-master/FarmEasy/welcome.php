<!DOCTYPE html>
	<html>
	<title>MEMBER ADDED</title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="styles.css">
	<link rel="stylesheet" href="font.css">
	<link href="https://fonts.googleapis.com/css?family=Open+Sans" rel="stylesheet">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="adsty.css">
	<style>
	body {
	   background: #3CB371;
	  }
	body,h1,h2,h3,h4,h5,h6 {font-family: "Lato", sans-serif; }
	</style>
	<body>
	<a href="login.php" class="navi"><i class="fa fa-arrow-left"></i> GO BACK</a>
	<h1><span class="reg">YOU ARE REGISTERED AS A MEMBER!</span></h1>
</body>
	</html>